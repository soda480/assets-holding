#!/usr/bin/env python

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'ghrelease',
        version = '0.0.1',
        description = 'A Python script to facilitate creation of GitHub releases',
        long_description = '',
        author = 'Emilio Reyes',
        author_email = 'emilio.reyes@intel.com',
        license = '',
        url = 'https://github.com/soda480/create-github-release',
        scripts = [],
        packages = ['ghrelease'],
        namespace_packages = [],
        py_modules = [],
        classifiers = [
            'Development Status :: 3 - Alpha',
            'Programming Language :: Python'
        ],
        entry_points = {
            'console_scripts': ['create-github-release = ghrelease.cli:main']
        },
        data_files = [],
        package_data = {},
        install_requires = ['python-magic'],
        dependency_links = ['git+https://github.com/soda480/github3api.git@master#egg=github3api'],
        zip_safe = True,
        cmdclass = {'install': install},
        keywords = '',
        python_requires = '',
        obsoletes = [],
    )
