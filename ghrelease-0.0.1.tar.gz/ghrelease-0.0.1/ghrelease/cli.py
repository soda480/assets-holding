
# Copyright (c) 2020 Intel Corporation

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#      http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from ghrelease import GitHubAPI2
from argparse import ArgumentParser
from os import getenv
import sys
import json

import logging
logger = logging.getLogger(__name__)


class MissingArgumentError(Exception):
    """ argument error
    """
    pass


def get_parser():
    """ setup parser and return parsed command line arguments
    """
    parser = ArgumentParser(
        description='A Python script to facilitate creation of GitHub releases')
    parser.add_argument(
        '--debug',
        dest='debug',
        action='store_true',
        help='display debug messages to stdout')
    parser.add_argument(
        '--execute',
        dest='execute',
        action='store_true',
        help='execute processing - not setting is same as running in NOOP mode')
    return parser


def validate(args):
    """ validate args
    """
    pass


def get_client():
    """ return instance of GitHubAPI2
    """
    return GitHubAPI2.get_client()


def set_logging(args):
    """ configure logging
    """
    rootLogger = logging.getLogger()
    # must be set to this level so handlers can filter from this level
    rootLogger.setLevel(logging.DEBUG)

    logfile = '{}/create-github-release.log'.format(getenv('PWD'))
    file_handler = logging.FileHandler(logfile)
    file_formatter = logging.Formatter("%(asctime)s %(processName)s %(name)s [%(funcName)s] %(levelname)s %(message)s")
    file_handler.setFormatter(file_formatter)
    file_handler.setLevel(logging.DEBUG)
    rootLogger.addHandler(file_handler)

    stream_handler = logging.StreamHandler()
    formatter = '%(asctime)s %(name)s [%(funcName)s] %(levelname)s %(message)s'
    stream_formatter = logging.Formatter(formatter)
    stream_handler.setFormatter(stream_formatter)
    stream_handler.setLevel(logging.DEBUG if args.debug else logging.INFO)
    rootLogger.addHandler(stream_handler)


def main():
    """ main function
    """
    parser = get_parser()
    try:
        args = parser.parse_args()
        validate(args)
        set_logging(args)
        get_client()

    except MissingArgumentError as exception:
        parser.print_usage()
        logger.error("ERROR: {}".format(str(exception)))

    except Exception as exception:
        logger.error("ERROR: {}".format(str(exception)))
        sys.exit(-1)


if __name__ == '__main__':  # pragma: no cover

    main()
